<div class="row">
	<button type="button" class="btn btn-primary addDoctor" data-toggle="modal" data-target="#addModal">הוספת טיפול</button>
	<input type="text" placeholder="חפש סוג טיפול" id="search_type">
</div>

<div class="row">
	<div class="col-md-12">
		<table class="table table-bordered typeList">
		</table>
	</div>
</div>

<div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">הוספת טיפול</h4>
      </div>
      <div class="modal-body">
			שם הטיפול:<br>
			 <input type="text" class="addType" value="" required>
			 <br>			          
		 
			הסבר:<br>
			 <textarea class="addDescription" required></textarea>
			 <br>
			 
			משך הטיפול:<br>
			 <input type="number" class="addTime" value="" required>
			 <br>	
			 
			<button type="button" class="btn btn-primary addBtn">הוספת טיפול</button>
			<p class="bg-danger addErr" style="display:none"></p>
      </div>     
    </div>
  </div>
</div>



<div class="modal fade" id="updateModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">עדכון טיפול</h4>
      </div>
      <div class="modal-body">
			<div class="updateInfo">
			</div>
		
			<button type="button" class="btn btn-primary updateBtn">עדכון טיפול</button>
			<p class="bg-danger updateErr" style="display:none"></p>
      </div>     
    </div>
  </div>
</div>
<script src="js/treatment.js"></script>