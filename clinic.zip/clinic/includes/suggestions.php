

<input type="text" placeholder="חפש המלצות" id="search_suggestions">
<div class="row show_suggestions">

</div>

<script src="js/suggestions.js"></script>
