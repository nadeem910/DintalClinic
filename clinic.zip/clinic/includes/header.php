<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		
		<title>מרכז טיפול השן</title>
	
		<meta name="viewport" content="width=device-width, initial-scale=1">
		
		<script type="text/javascript" src="js/jquery-3.2.0.js"></script>
		
		<!-- Latest compiled and minified CSS -->
		<link rel="stylesheet" href="css/bootstrap.min.css">
		
		<link href="https://fonts.googleapis.com/css?family=Varela+Round" rel="stylesheet">
		
		<!-- Latest compiled and minified JavaScript -->
		<script src="js/bootstrap.min.js"></script>
		
		<link href="css/styles.css" type="text/css" rel="stylesheet">