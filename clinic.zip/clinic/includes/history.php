<div בlass="row">
	<div class="col-md-offset-3 col-md-6">
		<h1>דו"ח טיפולים</h1>
		<a href="javascript:print()"><span class="glyphicon glyphicon-print"></span></a><br>
		<span class="glyphicon glyphicon-search" aria-hidden="true"></span> <input type="text" placeholder="חפש לקוח" id="search_treatment">
	</div>
</div>
<div class="row">
	<div class="col-md-offset-3 col-md-6 getTreatments">
		
	</div>
</div>

<script src="js/clients.js"></script>
