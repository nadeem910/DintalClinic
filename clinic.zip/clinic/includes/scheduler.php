<input size="16" type="text" id="datepicker" style="z-index:999999999!important" readonly class="form_datetime">  
	<span id="del_calendar" class="glyphicon glyphicon-calendar"></span><br><br>  
	
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script type="text/javascript">
</script>
<a href="javascript:print()"><span class="glyphicon glyphicon-print"></span></a>
<div class="row">
	<div class="list-group">
	  <a href="javascript:;" class="list-group-item active" style="z-index:1">		
	  </a>
		<div class="treatments">
		</div>
	</div>
</div>
<script src="js/scheduler.js"></script>
